//*@@@+++@@@@******************************************************************
//
// Microsoft Windows Media Foundation
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//*@@@---@@@@******************************************************************

#pragma once

namespace Microsoft { namespace Windows { namespace MediaReaders {

const unsigned int c_audioStreamSinkId = 0;
const unsigned int c_videoStreamSinkId = 1;

class MediaSink WrlSealed
    : public Microsoft::WRL::RuntimeClass<
    Microsoft::WRL::RuntimeClassFlags<
    Microsoft::WRL::RuntimeClassType::WinRtClassicComMix>
    , ABI::Windows::Media::IMediaExtension
    , IMFMediaSink
    , IMFClockStateSink
    , Microsoft::WRL::FtmBase
    >
{
    InspectableClass(L"MediaSink", BaseTrust)

public:

    MediaSink()
        : _shutdown(false)
    {
    }

    HRESULT RuntimeClassInitialize(
        __in_opt ABI::Windows::Media::MediaProperties::IAudioEncodingProperties* audioProps,
        __in_opt ABI::Windows::Media::MediaProperties::IVideoEncodingProperties* videoProps,
        MediaReaders::SampleHandler^ audioSampleHandler,
        MediaReaders::SampleHandler^ videoSampleHandler
        )
    {
        HRESULT hr = S_OK;

        Microsoft::WRL::ComPtr<IMFMediaType> audioMT;
        if (audioProps != nullptr)
        {
            CHK_RETURN(MFCreateMediaTypeFromProperties(audioProps, &audioMT));
            CHK_RETURN(Microsoft::WRL::Details::MakeAndInitialize<MediaStreamSink>(&_audioStreamSink, this, c_audioStreamSinkId, audioMT.Get(), audioSampleHandler));
        }

        Microsoft::WRL::ComPtr<IMFMediaType> videoMT;
        if (videoProps != nullptr)
        {
            CHK_RETURN(MFCreateMediaTypeFromProperties(videoProps, &videoMT));
            CHK_RETURN(Microsoft::WRL::Details::MakeAndInitialize<MediaStreamSink>(&_videoStreamSink, this, c_videoStreamSinkId, videoMT.Get(), videoSampleHandler));
        }

        return S_OK;
    }

    HRESULT RequestAudioSample()
    {
        auto lock = _lock.LockExclusive();

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        return _audioStreamSink->RequestSample();
    }

    HRESULT RequestVideoSample()
    {
        auto lock = _lock.LockExclusive();

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        return _videoStreamSink->RequestSample();
    }

    HRESULT SetCurrentAudioMediaType(IMFMediaType* mt)
    {
        auto lock = _lock.LockExclusive();

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        return _audioStreamSink->InternalSetCurrentMediaType(mt);
    }

    HRESULT SetCurrentVideoMediaType(IMFMediaType* mt)
    {
        auto lock = _lock.LockExclusive();

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        return _videoStreamSink->InternalSetCurrentMediaType(mt);
    }

    //
    // IMediaExtension
    //

    IFACEMETHOD(SetProperties) (ABI::Windows::Foundation::Collections::IPropertySet * /*configuration*/)
    {
        auto lock = _lock.LockExclusive();

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        return S_OK;
    }

    //
    // IMFMediaSink
    //

    IFACEMETHOD(GetCharacteristics) (DWORD *characteristics)
    {
        if (characteristics == nullptr)
        {
            return OriginateError(E_POINTER, L"characteristics");
        }

        *characteristics = MEDIASINK_RATELESS | MEDIASINK_FIXED_STREAMS;

        return S_OK;
    }

    IFACEMETHOD(AddStreamSink)(DWORD /*streamSinkIdentifier*/, IMFMediaType * /*mediaType*/, IMFStreamSink **streamSink)
    {
        if (streamSink == nullptr)
        {
            return OriginateError(E_POINTER, L"ppStreamSink");
        }
        *streamSink = nullptr;

        return OriginateError(MF_E_STREAMSINKS_FIXED);
    }

    IFACEMETHOD(RemoveStreamSink) (DWORD /*streamSinkIdentifier*/)
    {
        return OriginateError(MF_E_STREAMSINKS_FIXED);
    }

    IFACEMETHOD(GetStreamSinkCount) (_Out_ DWORD *streamSinkCount)
    {
        if (streamSinkCount == nullptr)
        {
            return OriginateError(E_POINTER, L"streamSinkCount");
        }

        *streamSinkCount = (_audioStreamSink != nullptr) + (_videoStreamSink != nullptr);

        return S_OK;
    }

    IFACEMETHOD(GetStreamSinkByIndex) (DWORD index, _Outptr_ IMFStreamSink **streamSink)
    {
        auto lock = _lock.LockExclusive();

        if (streamSink == nullptr)
        {
            return OriginateError(E_POINTER, L"streamSink");
        }
        *streamSink = nullptr;

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        switch (index)
        {
        case 0:
            if (_audioStreamSink != nullptr)
            {
                return _audioStreamSink.CopyTo(streamSink);
            }
            else
            {
                return _videoStreamSink.CopyTo(streamSink);
            }
        case 1:
            if ((_audioStreamSink != nullptr) && (_videoStreamSink != nullptr))
            {
                return _videoStreamSink.CopyTo(streamSink);
            }
            else
            {
                return OriginateError(E_INVALIDARG, L"index");
            }
        default:
            return OriginateError(E_INVALIDARG, L"index");
        }
    }

    IFACEMETHOD(GetStreamSinkById) (DWORD identifier, IMFStreamSink **streamSink)
    {
        auto lock = _lock.LockExclusive();

        if (streamSink == nullptr)
        {
            return OriginateError(E_POINTER, L"ppStreamSink");
        }
        *streamSink = nullptr;

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        if ((identifier == 0) && (_audioStreamSink != nullptr))
        {
            return _audioStreamSink.CopyTo(streamSink);
        }
        else if ((identifier == 1) && (_videoStreamSink != nullptr))
        {
            return _videoStreamSink.CopyTo(streamSink);
        }
        else
        {
            return OriginateError(E_INVALIDARG, L"identifier");
        }
    }

    IFACEMETHOD(SetPresentationClock) (IMFPresentationClock *clock)
    {
        auto lock = _lock.LockExclusive();
        HRESULT hr = S_OK;

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        if (_clock != nullptr)
        {
            CHK_RETURN(_clock->RemoveClockStateSink(this));
            _clock = nullptr;
        }

        if (clock != nullptr)
        {
            CHK_RETURN(clock->AddClockStateSink(this));
            _clock = clock;
        }

        return S_OK;
    }

    IFACEMETHOD(GetPresentationClock) (IMFPresentationClock **clock)
    {
        auto lock = _lock.LockExclusive();
        HRESULT hr = S_OK;

        if (clock == nullptr)
        {
            return OriginateError(E_POINTER, L"clock");
        }
        *clock = nullptr;

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        if (_clock != nullptr)
        {
            CHK_RETURN(_clock.CopyTo(clock))
        }

        return S_OK;
    }

    IFACEMETHOD(Shutdown) ()
    {
        auto lock = _lock.LockExclusive();

        if (_shutdown)
        {
            return S_OK;
        }
        _shutdown = true;

        if (_audioStreamSink != nullptr)
        {
            _audioStreamSink->Shutdown();
            _audioStreamSink = nullptr;
        }

        if (_videoStreamSink != nullptr)
        {
            _videoStreamSink->Shutdown();
            _videoStreamSink = nullptr;
        }

        if (_clock != nullptr)
        {
            (void)_clock->RemoveClockStateSink(this);
            _clock = nullptr;
        }

        return S_OK;
    }

    //
    // IMFClockStateSink methods
    //

    IFACEMETHOD(OnClockStart) (MFTIME /*hnsSystemTime*/, LONGLONG /*llClockStartOffset*/)
    {
        auto lock = _lock.LockExclusive();

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        return S_OK;
    }

    IFACEMETHOD(OnClockStop) (MFTIME /*hnsSystemTime*/)
    {
        auto lock = _lock.LockExclusive();

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        return S_OK;
    }

    IFACEMETHOD(OnClockPause) (MFTIME /*hnsSystemTime*/)
    {
        auto lock = _lock.LockExclusive();

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        return S_OK;
    }

    IFACEMETHOD(OnClockRestart) (MFTIME /*hnsSystemTime*/)
    {
        auto lock = _lock.LockExclusive();

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        return S_OK;
    }

    IFACEMETHOD(OnClockSetRate) (MFTIME /*hnsSystemTime*/, float /*flRate*/)
    {
        auto lock = _lock.LockExclusive();

        if (_shutdown)
        {
            return OriginateError(MF_E_SHUTDOWN);
        }

        return S_OK;
    }

private:

    bool _shutdown;

    Microsoft::WRL::ComPtr<MediaStreamSink> _audioStreamSink;
    Microsoft::WRL::ComPtr<MediaStreamSink> _videoStreamSink;
    Microsoft::WRL::ComPtr<IMFPresentationClock> _clock;

    Microsoft::WRL::Wrappers::SRWLock _lock;
};

} } }
