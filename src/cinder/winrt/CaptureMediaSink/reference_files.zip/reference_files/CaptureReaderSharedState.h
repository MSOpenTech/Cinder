//*@@@+++@@@@******************************************************************
//
// Microsoft Windows Media Foundation
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//*@@@---@@@@******************************************************************

#pragma once

namespace Microsoft { namespace Windows { namespace MediaReaders {

namespace WF = ::Windows::Foundation;
namespace WFC = ::Windows::Foundation::Collections;
namespace WMC = ::Windows::Media::Capture;
namespace WMMp = ::Windows::Media::MediaProperties;

ref class MediaReaderVideoStream;
ref class MediaReaderAudioStream;
ref class MediaReaderOtherStream;
ref struct MediaReaderCaptureInitializationSettings;
ref class MediaReaderReadResult;
class MediaSink;

private ref class CaptureReaderSharedState sealed : public IReaderSharedState
{
public:

    virtual void CreateStreams(
        _Outptr_ WFC::IVectorView<MediaReaderAudioStream^>^* audioStreams,
        _Outptr_ WFC::IVectorView<MediaReaderVideoStream^>^* videoStreams,
        _Outptr_ WFC::IVectorView<MediaReaderOtherStream^>^* otherStreams
        );

    virtual WF::IAsyncAction^ CompleteInitializationAsync();

    virtual WF::IAsyncAction^ FinishAsync();

    virtual GraphicsCore::SharedGraphicsDevice^ GetGraphicsDevice()
    {
        return _graphicsDevice;
    }

    virtual WF::IAsyncOperation<MediaReaderReadResult^>^ ReadAudioAsync(unsigned int streamIndex);
    virtual WF::IAsyncOperation<MediaReaderReadResult^>^ ReadVideoAsync(unsigned int streamIndex);
    virtual WF::IAsyncOperation<MediaReaderReadResult^>^ ReadOtherAsync(unsigned int /*streamIndex*/)
    {
        RoFailFastWithErrorContext(E_UNEXPECTED);
        return nullptr;
    }

    virtual WMMp::AudioEncodingProperties^ GetCurrentAudioStreamProperties(unsigned int streamIndex);
    virtual WMMp::VideoEncodingProperties^ GetCurrentVideoStreamProperties(unsigned int streamIndex);
    virtual WMMp::IMediaEncodingProperties^ GetCurrentOtherStreamProperties(unsigned int /*streamIndex*/)
    {
        RoFailFastWithErrorContext(E_UNEXPECTED);
        return nullptr;
    }

    virtual WFC::IVectorView<WMMp::AudioEncodingProperties^>^ GetNativeAudioStreamProperties(unsigned int streamIndex);
    virtual WFC::IVectorView<WMMp::VideoEncodingProperties^>^ GetNativeVideoStreamProperties(unsigned int streamIndex);
    virtual WFC::IVectorView<WMMp::IMediaEncodingProperties^>^ GetNativeOtherStreamProperties(unsigned int /*streamIndex*/)
    {
        RoFailFastWithErrorContext(E_UNEXPECTED);
        return nullptr;
    }

    virtual WF::IAsyncAction^ SetCurrentAudioStreamPropertiesAsync(unsigned streamIndex, _In_ WMMp::AudioEncodingProperties^ properties);
    virtual WF::IAsyncAction^ SetCurrentVideoStreamPropertiesAsync(unsigned streamIndex, _In_ WMMp::VideoEncodingProperties^ properties);
    virtual WF::IAsyncAction^ SetCurrentOtherStreamPropertiesAsync(unsigned /*streamIndex*/, _In_ WMMp::IMediaEncodingProperties^ /*properties*/)
    {
        RoFailFastWithErrorContext(E_UNEXPECTED);
        return nullptr;
    }

    virtual WF::IAsyncAction^ SetNativeAudioStreamPropertiesAsync(unsigned int streamIndex, _In_ WMMp::AudioEncodingProperties^ properties);
    virtual WF::IAsyncAction^ SetNativeVideoStreamPropertiesAsync(unsigned int streamIndex, _In_ WMMp::VideoEncodingProperties^ properties);
    virtual WF::IAsyncAction^ SetNativeOtherStreamPropertiesAsync(unsigned int /*streamIndex*/, _In_ WMMp::IMediaEncodingProperties^ /*properties*/)
    {
        RoFailFastWithErrorContext(E_UNEXPECTED);
        return nullptr;
    }

    virtual void SetAudioSelection(unsigned int streamIndex, bool selected);
    virtual void SetVideoSelection(unsigned int streamIndex, bool selected);
    virtual void SetOtherSelection(unsigned int /*streamIndex*/, bool /*selected*/)
    {
        RoFailFastWithErrorContext(E_UNEXPECTED);
    }

    virtual bool GetAudioSelection(unsigned int streamIndex);
    virtual bool GetVideoSelection(unsigned int streamIndex);
    virtual bool GetOtherSelection(unsigned int /*streamIndex*/)
    {
        RoFailFastWithErrorContext(E_UNEXPECTED);
        return false;
    }

internal:

    CaptureReaderSharedState(_In_ WMC::MediaCapture^ capture, _In_ MediaReaderCaptureInitializationSettings^ settings);

private:

    ~CaptureReaderSharedState();

    GraphicsCore::SharedGraphicsDevice^ _GetSharedGraphicsDevice(_In_ WMC::MediaCapture^ capture) const;

    void ProcessAudioSample(BufferCore::IMediaBufferReference^ sample);
    void ProcessVideoSample(BufferCore::IMediaBufferReference^ sample);

    void _VerifyNotClosed()
    {
        if ((_state == State::Closing) || (_state == State::Closed))
        {
            throw ref new Platform::ObjectDisposedException();
        }
    }

    WMC::MediaStreamType _GetVideoStreamType() const
    {
        switch (_streamType)
        {
        case CaptureStreamType::Preview: return WMC::MediaStreamType::VideoPreview;
        case CaptureStreamType::Record: return WMC::MediaStreamType::VideoRecord;
        default: RoFailFastWithErrorContext(E_UNEXPECTED); return WMC::MediaStreamType::Audio;
        }
    }

    enum class State
    {
        Created,
        Starting,
        Started,
        Closing,
        Closed
    } _state;

    CaptureStreamType _streamType;

    std::queue<concurrency::task_completion_event<MediaReaderReadResult^>> _audioSampleRequestQueue;
    std::queue<concurrency::task_completion_event<MediaReaderReadResult^>> _videoSampleRequestQueue;

    Microsoft::WRL::ComPtr<MediaSink> _mediaSink;
    Microsoft::WRL::ComPtr<MediaCore::InteropServices::IMediaBufferNativeFactory> _factory;
    ::Windows::Media::MediaProperties::MediaEncodingProfile^ _encodingProfile;
    ::Windows::Media::IMediaExtension^ _mediaExtension;
    GraphicsCore::SharedGraphicsDevice^ _graphicsDevice; // null if not HW accelerated
    Platform::Agile<WMC::MediaCapture> _capture;
    unsigned int _streamCount;
    bool _audioSelected;
    bool _videoSelected;
    Microsoft::WRL::Wrappers::SRWLock _lock;
};

} } }