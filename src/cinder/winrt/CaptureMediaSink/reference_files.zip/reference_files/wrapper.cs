private async void QuickDemoCapture()
        {
            var image = new WriteableBitmap((int)props.Width, (int)props.Height);
            PreviewVideo2.Source = image;
 
            var capture = new MediaCapture();
            await capture.InitializeAsync();
 
            var reader = await MediaReader.CreateFromMediaCaptureAsync(capture); // PCM + NV12
 
            using (var result = await reader.VideoStreams[0].ReadAsync())
            {
                await MediaBuffer2D.CopyToContiguousIBufferAsync(result.Buffer, image);
            }
        }
